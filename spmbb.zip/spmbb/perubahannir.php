<?php 
include 'bootstrap.php'; ?>

<style>
  fieldset{
    border
  }
</style>
<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Bootstrap -->

  <title>Proses Penilaian Massal</title>
</head>
<body>
<?php 
include 'navbar.php'; ?>
<br><br><br><br><br><br><br><br><br><br><br><br>
<form>
        <fieldset>
        <legend>asdihajsdh  </legend>
        <label for="tanggal">Tanggal pendataan</label>
        <input type="" name="">
        <br>
        <label>NIP pendata</label>
        <input type="" name="">
        </fieldset>



<div class="container">
  <div class="row">
    <div class="col-md-10 col-md-offset-1">
      <div class="panel panel-default">
        <div class="panel-heading">Perubahan Nir </div>

        <div class="panel-body">
          provinsi : <input type="" name="" width="1px"> <input type="" name=""><br>
        kota/kab : <input type="" name=""> <input type="" name=""><br>
        kecamatan : <input type="" name=""> <input type="" name=""><br>
        kelurahan : <input type="" name=""> <input type="" name=""><br>
        tahun : <input type="" name=""> NO Dokumen: <input type="" name=""><br>
<hr>
        <div class="col-md-2">
          kode znt
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
        </div>
         <div class="col-md-2">
          NIR
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
          <input type="" name="">
        </div>

        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>