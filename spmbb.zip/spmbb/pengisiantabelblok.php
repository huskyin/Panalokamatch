<?php 
include 'bootstrap.php'; ?>

<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Bootstrap -->

  <title>Proses Penilaian Massal</title>
</head>
<body>
<?php 
include 'navbar.php'; ?>


<div class="container-fluid">
  <div class="row">
    <div class="col-md-10 col-md-offset-1">
      <div class="panel panel-default">
        <div class="panel-heading">pengisian Tabel Blok</div>

        <div class="panel-body">
        
        provinsi : <input type="" name="" width="1px"> <input type="" name=""><br>
        kota/kab : <input type="" name=""> <input type="" name=""><br>
        kecamatan : <input type="" name=""> <input type="" name=""><br>
        kelurahan : <input type="" name=""> <input type="" name=""><br><hr>
        <div class="container">
          <div class="kurung">
          <table>
            <tr>
              <td>kode block</td>
              <td>checkbox</td>
              <td align="center">status peta</td>
            </tr>
            <tr>
              <td>
                <input type="" name="">
              </td>
              <td>
                <input type="checkbox" name="" align="center">
              </td>
              <td>tidak ada peta</td>
            </tr>
            <tr>
              <td>
                <input type="" name="">
              </td>
              <td>
                <input type="checkbox" name="">
              </td>
            </tr>
            <tr>
              <td>
                <input type="" name="">
              </td>
              <td>
                <input type="checkbox" name="">
              </td>
            </tr>
            <tr>
              <td>
                <input type="" name="">
              </td>
              <td>
                <input type="checkbox" name="">
              </td>
            </tr>
            <tr>
              <td>
                <input type="" name="">
              </td>
              <td>
                <input type="checkbox" name="">
              </td>
            </tr>
            <tr>
              <td>
                <input type="" name="">
              </td>
              <td>
                <input type="checkbox" name="">
              </td>
            </tr>
            <tr>
              <td>
                <input type="" name="">
              </td>
              <td>
                <input type="checkbox" name="">
              </td>
            </tr>
            <tr>
              <td>
                <input type="" name="">
              </td>
              <td>
                <input type="checkbox" name="">
              </td>
            </tr>
            <tr>
              <td>
                <input type="" name="">
              </td>
              <td>
                <input type="checkbox" name="">
              </td>
            </tr>
          </table>
        </div>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>