<?php 
include 'bootstrap.php'; ?>

<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>SPMBB</title>
</head>
<link href="css/main.css" rel="stylesheet">
<body>

<?php 
include 'navbar.php'; ?>


    <header>
        <div class="container">
            <div class="header-content">
                <h1><span>Aplikasi </span> Pajak</h1>
                <h3>Lorem Ipsum</h3> </div>
        </div>
    </header>



<br><br><br><br><br><br><br>

</body>
</html>