<script>
$(document).ready(function(){
  $('.dropdown-submenu2 a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});
</script>
<nav class="navbar navbar-default  asd ">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->

   


    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">File<span class="caret"></span></a>
          <ul class="dropdown-menu">
          <li><a href="admin.php">Administrasi pemakaian</a></li>
            <li><a href="#">Backup</a></li>
            <li><a href="#">Keluar</a></li>
          </ul>
        </li>







        <li class="dropdown">
          <a href="pendataan.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">pendataan <span class="caret"></span></a>



         
                      <!-- Cara bikin menu child bertingkat:
                      Sumur: http://www.w3schools.com/Bootstrap/tryit.asp?filename=trybs_ref_js_dropdown_multilevel_css&stacked=h 
                      http://www.bootply.com/66089

                      YANG KEPAKE, Thanks MAn!!
                      https://github.com/RobinRadic/bootstrap-advanced-dropdowns
                      -->

            


        <ul class="dropdown-menu"> 
            <li class="dropdown-submenu2">
                <a class="test" tabindex="-1" href="#">Persiapan <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                       <li><a tabindex="-1" href="#">2nd level dropdown</a></li>
                        <li><a tabindex="-1" href="#">2nd level dropdown</a></li>
                    </ul>
            </li>
            <li><a href="penilaian.php">Pendataan Objek Pajak</a></li>
            <li><a href="penilaian.php">Laporan Pendataan Op</a></li>
            <li><a href="penilaian.php">Sistep</a></li>
            <li><a href="#">Pemekaran Wilayah </a></li>
            <li><a href="penilaian.php">Daftar Fasilitas Umum</a></li>
            <li><a href="penilaian.php">Daftar Op Tanah Kosong</a></li>
            <li><a href="penilaian.php">Daftar Nilai Individu</a></li>
            <li><a href="penilaian.php">Pemeliharaan Data Piutang</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="penilaian.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Penilaian <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="penilaian.php">Penilaian Massal</a></li>
            <li><a href="#">Laporan Penilaian</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="penilaian.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">penetapan <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="penilaian.php">Setting pencetakan</a></li>
            <li><a href="#">PBB minimal</a></li>
            <li><a href="#">Penetapan dan Pencetakan massal</a></li>
            <li><a href="#">Salinan massal</a></li>
            <li><a href="#">penetapan dan pencetakan terseleksi</a></li>
            <li><a href="#">informasi SPPT/SKP</a></li>
            <li><a href="#">Penundaan tanggal jatuh tempo </a></li>
            <li><a href="#">Laporan distribusi op</a></li>
            <li><a href="#">laporan himpunan ketetapan PBB/NJOP</a></li>
            <li><a href="#">Tanda terima SPPT/SKP/STP</a></li><hr>
            <li><a href="#">Simulasi penetapan</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="penilaian.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Penagihan  <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="penilaian.php">Daftar Tunggakan </a></li>
            <li><a href="#">Pengeluaran Himbauan </a></li>
            <li><a href="#">Laporan Op Tunggakan  </a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="penilaian.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Pembayaran    <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="penilaian.php">Laporan pembayaran  </a></li>
            <li><a href="#">laporan eksekusi pembayaran </a></li>
            <li><a href="#">Surat keterangan pembayaran </a></li>
            <li><a href="#">pencataan pembayaran  </a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="penilaian.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">pelayanan<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="penilaian.php">Parameter keluaran </a></li>
            <li><a href="#">Input permohonan </a></li>
            <li><a href="#">Cek tanda terima</a></li><hr>
            <li><a href="#">Atur Berkas</a></li>
            <li><a href="#">Monitoring pelayanan </a></li><hr>
            <li><a href="#">Administrasi OP Baru Daan Mutasi </a></li>
            <li><a href="#">Pengurangan</a></li>
            <li><a href="#">Keberatan </a></li>
            <li><a href="#">Restitusi dan Kompensasi</a></li>
            <li><a href="#">Pembetulan Kompensasi SPPT/SKP</a></li>
            <li><a href="#">Pembatalan Kompensasi SPPT/SKP</a></li><hr>
            <li><a href="#">Cek Keluaran </a></li>
            <li><a href="#">Penyerahan berkas Pelayanan Selesai ke WP</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="penilaian.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Lihat  <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="penilaian.php">Daftar SPOP/LSPOP</a></li>
            <li><a href="#">daftar ringkas</a></li>
            <li><a href="#">Daftar OP dengan keringanan permanen </a></li>
            <li><a href="#">daftar objek bersama </a></li>
            <li><a href="#">daftar objek dengan nilai individu </a></li>
            <li><a href="#">catatan pembayaran PBB</a></li>
            <li><a href="#">Catatan sejarah </a></li>
            <li><a href="#">daftar rekapitulasi OP</a></li>
            <li><a href="#">Daftar Op yang telah dihapus </a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="penilaian.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">refrensi <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="penilaian.php">Wilayah </a></li>
            <li><a href="#">Kepegawaian </a></li>
            <li><a href="#">tempat pembayaran</a></li>
            <li><a href="#">tempat pembayaran SPPT Massal</a></li>
            <li><a href="#">Ressource</a></li>
            <li><a href="#">NJOPTKP</li><hr>
            <li><a href="#">Pengaturan menu </a></li>
            <li><a href="#">Ref umum</a></li>
          </ul>
        </li>

    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>