<?php 
include 'bootstrap.php'; ?>


<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SPMBB</title>
</head>
<body>
<?php 
include 'navbar.php'; ?>

<div class="container">
  <div class="row">
    <div class="col-md-10 col-md-offset-1">
      <div class="panel panel-default"  style="margin-top:100px;">
        <div class="panel-heading">Administrasi Pemakai</div>

        <div class="panel-body" >
        <div>user Login<select name="user">
<option value="0">admin</option>
<option value="1">editor</option>
<option value="2">member</option>
</select><hr>

                <table>
                <tr>
                <td >NIP </td><td><input  class="form-control"  style="margin-bottom:10px;" type="text" name="nip" placeholder="0666666666" >
                </td><td><input class="form-control"  style="margin-bottom:10px;" type="text" name="operator" placeholder="OPERATOR" ></td>
                </tr>
                </table>

               <table style="border-spacing:5em;" >
                
                <tr>
                <td> Nama login</td><td>:  </td><td ><input class="form-control" style="margin-bottom:10px; margin-left:10px;"  type="text" name="nama"></td>
                </tr>
                <tr>
                <td> Password Pengubah</td><td >:  </td><td><input class="form-control" style="margin-bottom:10px;margin-left:10px;" type="text" name="password"></td>
                </tr>
                <tr >
                <td> Password Baru</td><td >:  </td><td><input class="form-control" style="margin-bottom:10px;margin-left:10px;" type="text" name="passwordbaru"></td>
                </tr>
                 <tr>
                <td> Ulangi Password Baru</td><td >:  </td><td><input class="form-control" style="margin-bottom:10px;margin-left:10px;" type="text" name="ulangi"></td>
                </tr>


               </table>
    
    
      <input type="button" value="Ubah">
      <input type="button" value="Hapus">
      <input type="button" value="Baru">
      <input type="button" value="Simpan">
      <input type="button" value="Batal">
      <input type="button" value="Menu Utama">
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>