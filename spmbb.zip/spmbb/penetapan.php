<?php 
include 'bootstrap.php'; ?>

<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SPMBB</title>
</head>
<body>
<?php 
include 'navbar.php'; ?>

<div class="container">
  <div class="row">
    <div class="col-md-10 col-md-offset-1">
      <div class="panel panel-default">
        <div class="panel-heading">User Login</div>

        <div class="panel-body">
               NIP: <input type="text" name="nip"><br>
      Nama login:<input type="text" name="nama"><br>
      Password Pengubah:<input type="text" name="password"><br>
      Password baru:<input type="text" name="passwordbaru"><br>
      Ulangi Password baru:<input type="text" name="ulangi"><br>
      <input type="button" value="Ubah">
      <input type="button" value="Hapus">
      <input type="button" value="Baru">
      <input type="button" value="Simpan">
      <input type="button" value="Batal">
      <input type="button" value="Menu Utama">
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>