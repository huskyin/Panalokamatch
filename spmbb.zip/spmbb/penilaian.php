<?php 
include 'bootstrap.php'; ?>

<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Bootstrap -->

  <title>Proses Penilaian Massal</title>
</head>
<body>
<?php 
include 'navbar.php'; ?>

<div class="container">
  <div class="row">
    <div class="col-md-10 col-md-offset-1">
      <div class="panel panel-default">
        <div class="panel-heading">Proses Penilaian Massal</div>

        <div class="panel-body">
          You are logged in!
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>